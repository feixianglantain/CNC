/****************************************************************
 * version.h
 * GrblHoming - zapmaker fork on github
 *
 * 14 July 2013
 * GPL License (see LICENSE file)
 * Software is provided AS-IS
 ****************************************************************/
#ifndef VERSION_H
#define VERSION_H
#define GRBL_CONTROLLER_NAME_AND_VERSION    "Grbl Controller 3.6.1"
#endif // VERSION_H
